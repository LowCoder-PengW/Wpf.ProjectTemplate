﻿namespace $safeprojectname$
{
    public static class RegionNames
    {
        public const string ContentRegion = "ContentRegion";
    }
}

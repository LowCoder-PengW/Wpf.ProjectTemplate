﻿namespace $safeprojectname$
{
    public interface IMessageService
    {
        string GetMessage();
    }
}
